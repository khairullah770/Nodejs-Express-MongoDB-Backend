const express = require('express');
const fs = require('fs');
const app = express();
const url = require('url');


const chatHistoryFile = 'chat_history.txt';


function logMessage(senderIP, message) {
    const logEntry = `${new Date().toLocaleString()} - ${senderIP}: ${message}\n`;
    
    // Append message to chat history file
    fs.appendFile(chatHistoryFile, logEntry, (err) => {
        if (err) {
            console.error('Error writing to chat history:', err);
        } else {
            console.log('Chat history updated.');
        }
    });
}


app.get('/', (req, res) => {
    const message = req.query.msg;  
    const senderIP = req.ip;  

    if (message) {
        console.log(`Message from ${senderIP}: ${message}`);
        logMessage(senderIP, message);  // Log message to file

        res.send('Message received.');
    } else {
        res.status(400).send('No message provided.');
    }
});


const PORT = 8080;
const HOST = '10.141.212.132'; 

app.listen(PORT, HOST, () => {
    console.log(`Your Chat server running at http://${HOST}:${PORT}/`);
});
