const express = require("express");
const fs = require("fs");
const users = require("./MOCK_DATA.json");

const app = express();
app.use(express.json());

// Function to classify IP addresses into classes A-E
const classifyIP = (ip) => {
  const firstOctet = Number(ip.split(".")[0]);
  if (firstOctet >= 1 && firstOctet <= 126) return "A";
  if (firstOctet >= 128 && firstOctet <= 191) return "B";
  if (firstOctet >= 192 && firstOctet <= 223) return "C";
  if (firstOctet >= 224 && firstOctet <= 239) return "D";
  if (firstOctet >= 240 && firstOctet <= 255) return "E";
  return null;
};

// POST method to classify users based on IP address and write to JSON files
app.post("/ip", (req, res) => {
  const Aclass = [];
  const Bclass = [];
  const Cclass = [];
  const Dclass = [];
  const Eclass = [];

  users.forEach((user) => {
    const ipClass = classifyIP(user.ip_address);
    if (ipClass === "A") Aclass.push(user);
    else if (ipClass === "B") Bclass.push(user);
    else if (ipClass === "C") Cclass.push(user);
    else if (ipClass === "D") Dclass.push(user);
    else if (ipClass === "E") Eclass.push(user);
  });

  // Function to write classified users to a JSON file
  const writeToFile = (fileName, data) => {
    fs.writeFile(fileName, JSON.stringify(data, null, 2), (err) => {
      if (err) {
        console.error(`Error writing to ${fileName}:`, err);
      } else {
        console.log(`File ${fileName} created successfully.`);
      }
    });
  };

  // Write each class to its respective JSON file
  writeToFile("A.json", Aclass);
  writeToFile("B.json", Bclass);
  writeToFile("C.json", Cclass);
  writeToFile("D.json", Dclass);
  writeToFile("E.json", Eclass);

  // Return classified users as JSON response
  return res.json({
    Aclass,
    Bclass,
    Cclass,
    Dclass,
    Eclass,
  });
});

// GET route for all users
app.get("/api/users", (req, res) => {
  res.json(users); // Send all users as JSON
});

// GET route for a user by ID
app.get("/api/users/:id", (req, res) => {
  const userId = parseInt(req.params.id, 10); // Get user ID from params
  const user = users.find((u) => u.id === userId);

  if (user) {
    res.json(user); // If user found, send their details
  } else {
    res.status(404).json({ message: "User not found" }); // If user not found
  }
});

// Get users by first_name
app.get("/api/users/first_name/:first_name", (req, res) => {
  const firstName = req.params.first_name.toLowerCase();
  const filteredUsers = users.filter(
    (user) => user.first_name.toLowerCase() === firstName
  );

  if (filteredUsers.length > 0) {
    res.json(filteredUsers);
  } else {
    res.status(404).send("No users found with the given first name");
  }
});

app
  .route("/api/users/:id")
  .get((req, res) => {
    const id = Number(req.params.id);
    const user = users.find((user) => user.id === id);

    res.json(user);
  })
  .post((req, res) => {
    // Create a User
    const body = req.body;

    users.push({ id: users.length + 1, ...body }); // Spread operator to add new user

    // Write to file
    fs.writeFile("./MOCK_DATA.json", JSON.stringify(users), (err) => {
      if (err) {
        console.error(err);
        res.status(500).json({ message: "Error writing file" });
      } else {
        res.json({ message: "Success" });
      }
    });
  })
  .patch((req, res) => {
    // Get the user ID from the request parameters
    const id = Number(req.params.id);

    // Find the user with the specified ID
    const user = users.find((user) => user.id === id);

    // Check if the user exists
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    // Get the index of the user in the users array
    const index = users.indexOf(user);

    // Update the user data
    const updatedUser = Object.assign(user, req.body);

    // Replace the user at the specified index with the updated data
    users[index] = updatedUser;

    // Write the updated users array to the file
    fs.writeFile("./MOCK_DATA.json", JSON.stringify(users), (err) => {
      if (err) {
        return res.status(400).json({ message: "Failed to write in file" });
      }
      console.log(updatedUser);
      res
        .status(200)
        .json({ message: "Successfully written in file", updatedUser });
    });
  })
  .delete((req, res) => {
    // Delete a User if exists

    const id = Number(req.params.id);
    const user = users.find((user) => user.id === id);

    if (!user) {
      res.status(404).json("User doesnot Exist");
    }
    const index = users.indexOf(user);

    users.splice(index, 1); // deleting only that id

    fs.writeFile("./MOCK_DATA.json", JSON.stringify(users), (err) => {
      if (err) {
        res.status(400).json("Error writing in File");
      }

      res.status(200).json("File Deleted Successfully");
    });
  });

// GET routes for classified users based on IP classes
app.get("/api/users/A", (req, res) => {
  fs.readFile("A.json", "utf8", (err, data) => {
    if (err) {
      res.status(500).json({ message: "Error reading A.json file" });
    } else {
      res.json(JSON.parse(data));
    }
  });
});

app.get("/api/users/B", (req, res) => {
  fs.readFile("B.json", "utf8", (err, data) => {
    if (err) {
      res.status(500).json({ message: "Error reading B.json file" });
    } else {
      res.json(JSON.parse(data));
    }
  });
});

app.get("/api/users/C", (req, res) => {
  fs.readFile("C.json", "utf8", (err, data) => {
    if (err) {
      res.status(500).json({ message: "Error reading C.json file" });
    } else {
      res.json(JSON.parse(data));
    }
  });
});

app.get("/api/users/D", (req, res) => {
  fs.readFile("D.json", "utf8", (err, data) => {
    if (err) {
      res.status(500).json({ message: "Error reading D.json file" });
    } else {
      res.json(JSON.parse(data));
    }
  });
});

app.get("/api/users/E", (req, res) => {
  fs.readFile("E.json", "utf8", (err, data) => {
    if (err) {
      res.status(500).json({ message: "Error reading E.json file" });
    } else {
      res.json(JSON.parse(data));
    }
  });
});

app.put("/api/users/classD", (req, res) => {
    const updatedUsers = users.filter((user) => classifyIP(user.ip_address) === "D")
                               .map((user) => {
                                 user.organization = "QAU";
                                 return user;
                               });
  
    if (updatedUsers.length === 0) {
      return res.status(404).json({ message: "No users with Class D IP addresses found" });
    }
  
    fs.writeFile("./MOCK_DATA.json", JSON.stringify(users, null, 2), (err) => {
      if (err) {
        return res.status(500).json({ message: "Error updating organization" });
      }
  
      res.json({
        message: "Organization updated for users with Class D IP addresses",
        updatedUsers,
      });
    });
  });
  
  
// Start the server
const PORT = 8000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
