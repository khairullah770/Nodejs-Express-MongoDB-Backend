require('dotenv').config();  // Load environment variables from .env file
const http = require('http');
const nodemailer = require('nodemailer');
const axios = require('axios');
const fs = require('fs');
const twilio = require('twilio');  // Twilio for sending SMS
const schedule = require('node-schedule'); // For scheduling tasks

// Function to write logs to a file
function writeLog(data) {
    const timestamp = new Date().toISOString(); // Timestamp for the log entry
    const logMessage = `${timestamp} - ${data}\n`; // Format the log entry

    // Append data to 'log.txt' file
    fs.appendFile('log.txt', logMessage, (err) => {
        if (err) {
            console.error('Error writing to log file:', err);
        } else {
            console.log('Log data written to log.txt');
        }
    });
}

// Nodemailer setup for sending email
const transporter = nodemailer.createTransport({
    service: 'gmail', // You can use other services like 'smtp.mailtrap.io' or 'outlook'
    secure: true,
    port: 465,
    auth: {
        user: process.env.EMAIL_USER, // Your email address from .env file
        pass: process.env.EMAIL_PASS, // Your email password or app-specific password
    }
});

// Twilio setup for SMS
const client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);

// Function to fetch weather data for Islamabad
const getWeatherData = async () => {
    try {
        writeLog('User triggered weather data fetch...');
        const response = await axios.get(process.env.WEATHER_API_URL, {
            params: {
                q: 'Islamabad', // Location
                appid: process.env.WEATHER_API_KEY,
                units: 'metric',
            },
        });

        const { temp } = response.data.main;
        const { description } = response.data.weather[0];
        const rain = response.data.rain ? 'Yes' : 'No'; // Check if rain is expected

        writeLog(`Weather data fetched successfully. Temp: ${temp}°C, Condition: ${description}, Rain: ${rain}`);

        return {
            temperature: temp,
            condition: description,
            rainExpected: rain,
        };
    } catch (error) {
        writeLog(`Error fetching weather data: ${error.message}`);
        console.error('Error fetching weather data:', error.message);
        return null;
    }
};
//send sms
const sendSMS = async (message) => {
    try {
        writeLog("User triggered SMS send...");
        const msg = await client.messages.create({
            from: process.env.TWILIO_FROM_NUMBER,
            to: process.env.TO_NUMBER,
            body: message,
        });

        writeLog(`SMS sent successfully. Message SID: ${msg.sid}`);
        console.log("SMS sent successfully:", msg.sid);
    } catch (error) {
        writeLog(`Error sending SMS: ${error.message}`);
        console.error("Error sending SMS:", error.message);
    }
};


// Function to send email
const sendEmail = async (message) => {
    const mailOptions = {
        from: process.env.EMAIL_USER,  // Sender's email address
        to: process.env.EMAIL_TO,      // Recipient email address
        subject: 'Weather Notification',
        text: message,
    };

    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            console.log('Error: ' + error);
            writeLog('Error: ' + error);
        } else {
            console.log('Email sent: ' + info.response);
            writeLog('Email sent: ' + info.response);
        }
    });
};

// Function to generate weather alert
const sendWeatherAlert = async () => {
    writeLog("User triggered weather alert...");
    const weatherData = await getWeatherData();

    if (weatherData) {
        const { temperature, condition, rainExpected } = weatherData;
        const message = `Weather Update for Islamabad:
        ~ Temperature: ${temperature}°C
        ~ Condition: ${condition}
        ~ Rain Expected: ${rainExpected}`;

        writeLog(`Weather Alert: ${message}`);
        console.log('Weather Alert:', message);

        await sendSMS(message); // sending sms to phone number
        await sendEmail(message); // sending email
    } else {
        writeLog("No weather data available, skipping notifications.");
        console.log("No weather data available, skipping notifications.");
    }
};

// Schedule the weather alert every 30 seconds
schedule.scheduleJob('*/30 * * * * *', sendWeatherAlert);
writeLog("Scheduled job triggered by user.");

// Create HTTP server to handle email sending (as requested)
const server = http.createServer(async (req, res) => {
    if (req.method === 'GET' && req.url === '/send-email') {
        // Fetch weather data
        const weatherData = await getWeatherData();

        if (weatherData) {
            const { temperature, condition, rainExpected } = weatherData;
            const message = `Weather Update for Islamabad:
            ~ Temperature: ${temperature}°C
            ~ Condition: ${condition}
            ~ Rain Expected: ${rainExpected}`;

            // Send email
            await sendEmail(message);
            res.writeHead(200, { 'Content-Type': 'text/plain' });
            res.end('Weather notification email and SMS sent successfully');
           
        } else {
            res.writeHead(500, { 'Content-Type': 'text/plain' });
            res.end('Failed to fetch weather data');
        }
    } else {
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end('Route not found');
    }
});

// Start server
server.listen(3000, () => {
    console.log('Server is running on http://localhost:3000');
});
