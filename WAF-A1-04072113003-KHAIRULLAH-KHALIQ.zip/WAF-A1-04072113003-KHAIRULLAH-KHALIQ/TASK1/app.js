import express from 'express';
import path from 'path';
import connectDB from './db.js';
import universityRoutes from './routes/universityRoutes.js';

const app = express();
const PORT = 3000;

// Connect to MongoDB
connectDB();

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Static files and routes
app.use('/', universityRoutes);
app.use(express.static(path.resolve('views')));

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
