import express from 'express';
import fetch from 'node-fetch';
import University from '../models/University.js';

const router = express.Router();

// Fetch and store universities in a single collection
router.get('/fetch_and_store/:country', async (req, res) => {
    const { country } = req.params;
    const apiUrl = `http://universities.hipolabs.com/search?country=${country}`;

    try {
        const response = await fetch(apiUrl);
        const universities = await response.json();

        // Save universities to the database
        await University.insertMany(
            universities.map((uni) => ({
                name: uni.name,
                country: uni.country,
                web_pages: uni.web_pages,
                state_province: uni['state-province'],
            }))
        );

        res.send(`${universities.length} universities stored in the database for ${country}.`);
    } catch (error) {
        res.status(500).send('Error fetching and storing universities.');
    }
});

// Find universities in the capitals of five countries
router.get('/find_capitals', async (req, res) => {
    try {
        const universities = await University.find({
            state_province: { $regex: /capital/i }, // Assuming capitals are marked as "capital"
        });
        res.json(universities);
    } catch (error) {
        res.status(500).send('Error finding universities in capitals.');
    }
});

// Add new universities
router.post('/add_university', async (req, res) => {
    const { name, country, web_pages, state_province } = req.body;

    try {
        const newUniversity = new University({
            name,
            country,
            web_pages,
            state_province,
        });
        await newUniversity.save();
        res.send('University added successfully!');
    } catch (error) {
        res.status(500).send('Error adding university.');
    }
});

// Delete a university
router.delete('/delete_university/:id', async (req, res) => {
    try {
        await University.findByIdAndDelete(req.params.id);
        res.send('University deleted successfully!');
    } catch (error) {
        res.status(500).send('Error deleting university.');
    }
});

// Update university information
router.put('/update_university/:id', async (req, res) => {
    try {
        const updatedUniversity = await University.findByIdAndUpdate(
            req.params.id,
            req.body,
            { new: true }
        );
        res.json(updatedUniversity);
    } catch (error) {
        res.status(500).send('Error updating university.');
    }
});

export default router;
