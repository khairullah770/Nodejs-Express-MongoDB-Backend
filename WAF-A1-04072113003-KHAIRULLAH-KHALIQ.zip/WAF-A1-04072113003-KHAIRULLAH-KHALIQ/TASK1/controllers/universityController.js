import fetch from 'node-fetch';
import path from 'path';

// Display the form to search universities by country
export const getCountryForm = (req, res) => {
    res.sendFile(path.resolve('views/see_country_universities.html'));
};

// Display the form to search university by name
export const getUniversityForm = (req, res) => {
    res.sendFile(path.resolve('views/search_university.html'));
};

// Fetch and display universities by country
export const fetchUniversitiesByCountry = async (req, res) => {
    const { country } = req.body; // Get country from form
    const apiUrl = `http://universities.hipolabs.com/search?country=${country}`;

    try {
        const response = await fetch(apiUrl);
        const universities = await response.json();

        // Display raw JSON data on the browser
        res.send(`
            <h1>Universities in ${country}</h1>
            <p>Total: ${universities.length}</p>
            <ul>
                ${universities.map((uni) => `<li>${uni.name}</li>`).join('')}
            </ul>
            <pre>${JSON.stringify(universities, null, 2)}</pre>
        `);
    } catch (error) {
        res.status(500).send('Error fetching universities.');
    }
};

// Fetch and display university web page address by name
export const fetchUniversityByName = async (req, res) => {
    const { name } = req.body; // Get university name from form
    const apiUrl = 'http://universities.hipolabs.com/search?country=Pakistan'; // Assuming country Pakistan

    try {
        const response = await fetch(apiUrl);
        const universities = await response.json();
        const university = universities.find((uni) => uni.name.toLowerCase().includes(name.toLowerCase()));

        if (university) {
            console.log(`Web Page for ${name}: ${university.web_pages[0]}`);
            res.send(`
                <h1>University: ${university.name}</h1>
                <p>Website: <a href="${university.web_pages[0]}">${university.web_pages[0]}</a></p>
                <pre>${JSON.stringify(university, null, 2)}</pre>
            `);
        } else {
            res.send(`<h1>No university found with the name "${name}".</h1>`);
        }
    } catch (error) {
        res.status(500).send('Error fetching university information.');
    }
};
