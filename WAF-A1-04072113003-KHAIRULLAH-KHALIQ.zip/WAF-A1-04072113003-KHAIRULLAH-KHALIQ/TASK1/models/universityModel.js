import mongoose from 'mongoose';

const UniversitySchema = new mongoose.Schema({
    name: { type: String, required: true },
    country: { type: String, required: true },
    web_pages: [String],
    state_province: String,
    capital: String,
});

const University = mongoose.model('University', UniversitySchema);

export default University;
