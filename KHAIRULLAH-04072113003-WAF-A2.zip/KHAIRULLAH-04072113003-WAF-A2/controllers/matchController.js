const axios = require('axios');
const Match = require('../models/Match');

// Function to fetch and store match data
const getMatches = async (req, res) => {
  try {
    // Fetch match data from the API
    const response = await axios.get('https://api.cricapi.com/v1/currentMatches', {
      params: {
        apikey: '4d093668-41a7-4c96-837c-67e2d48aa074',
        offset: 0
      }
    });

    const matches = response.data.data.map(match => ({
      match_id: match.id,
      name: match.name,
      matchType: match.matchType,
      status: match.status,
      venue: match.venue,
      date: new Date(match.dateTimeGMT), // Convert to Date object
      teams: match.teams,
      score: match.score
    }));

    // Overwrite the collection with new data from the API
    await Match.deleteMany({});
    await Match.insertMany(matches);

    // Fetch the latest match data from MongoDB
    const allMatches = await Match.find();

    // Render the home page with match data
    res.render('home', { matches: allMatches });
  } catch (error) {
    console.error('Error fetching matches:', error);
    res.status(500).send('Internal Server Error');
  }
};

module.exports = { getMatches };
