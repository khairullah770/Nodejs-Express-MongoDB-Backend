const axios = require('axios');

// Function to search players
const searchPlayer = async (req, res) => {
  try {
    const query = req.query.query || ''; // Get the search query from the request

    // Fetch player data from the API if a query is provided
    let players = [];
    if (query) {
      const response = await axios.get('https://api.cricapi.com/v1/players', {
        params: {
          apikey: '4d093668-41a7-4c96-837c-67e2d48aa074',
          offset: 0,
        },
      });

      // Filter players based on the search query
      players = response.data.data.filter(player =>
        player.name.toLowerCase().includes(query.toLowerCase()) ||
        player.country.toLowerCase().includes(query.toLowerCase())
      );
    }

    // Render the search results with query and players
    res.render('search', {
      players,
      query,
      error: players.length === 0 && query ? 'No players found matching your search.' : null,
    });
  } catch (error) {
    console.error('Error searching players:', error);
    res.status(500).send('Internal Server Error');
  }
};

module.exports = { searchPlayer };
