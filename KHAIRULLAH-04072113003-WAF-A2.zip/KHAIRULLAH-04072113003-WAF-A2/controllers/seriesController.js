const axios = require('axios');
const Series = require('../models/series');

// Function to fetch and store series data
const getSeries = async (req, res) => {
  try {
    // Fetch series data from the API
    const response = await axios.get('https://api.cricapi.com/v1/series', {
      params: {
        apikey: '4d093668-41a7-4c96-837c-67e2d48aa074',
        offset: 0
      }
    });

    const series = response.data.data.map(series => ({
      id: series.id,
      name: series.name,
      startDate: series.startDate,
      endDate: series.endDate,
      odi: series.odi,
      t20: series.t20,
      test: series.test,
      squads: series.squads,
      matches: series.matches
    }));

    // Overwrite the collection with new data from the API
    await Series.deleteMany({}); // Clear previous series data
    await Series.insertMany(series); // Insert new series data

    // Fetch the latest series data from MongoDB
    const allSeries = await Series.find();

    // Render the series page with the data
    res.render('series', { series: allSeries });
  } catch (error) {
    console.error('Error fetching series:', error);
    res.status(500).send('Internal Server Error');
  }
};

module.exports = { getSeries };
