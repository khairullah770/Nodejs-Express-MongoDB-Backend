const express = require('express');
const router = express.Router();
const searchController = require('../controllers/searchController');

// Route to search for players
router.get('/search', searchController.searchPlayer);

module.exports = router;
