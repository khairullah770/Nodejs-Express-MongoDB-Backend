// routes/seriesRoutes.js
const express = require('express');
const router = express.Router();
const { getSeries } = require('../controllers/seriesController');

// Route to get and display all series
router.get('/series', getSeries);

module.exports = router;
