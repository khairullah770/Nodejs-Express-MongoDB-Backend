const express = require('express');
const router = express.Router();
const { getMatches } = require('../controllers/matchController');

// Home route to fetch and display matches
router.get('/', getMatches);

module.exports = router;
