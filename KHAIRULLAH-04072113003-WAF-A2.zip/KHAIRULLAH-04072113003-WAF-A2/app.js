const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const matchRoutes = require('./routes/matchRoutes');
const seriesRoutes = require('./routes/seriesRoutes');
const searchRoutes = require('./routes/searchRoutes');
const scoreboard = require('./routes/scoreboardRoutes')
const app = express();

const PORT = process.env.PORT || 3000;

// Set EJS as the view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Body parser middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// MongoDB connection (update this if using Atlas)
mongoose.connect('mongodb://127.0.0.1:27017/cricketDashboard', { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('Connected to MongoDB'))
  .catch((err) => console.error('Error connecting to MongoDB:', err));

// Match Routes
app.use('/', matchRoutes);
app.use('/',seriesRoutes);
app.use('/', searchRoutes);
app.use('/',scoreboard);
app.get('/cricfinal', (req, res) => {
  res.render('cricfinal');
});


app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
