const mongoose = require('mongoose');

// Define the schema for the series data
const seriesSchema = new mongoose.Schema({
  id: { type: String, required: true },
  name: { type: String, required: true },
  startDate: { type: String, required: true },
  endDate: { type: String, required: true },
  odi: { type: Number, required: true },
  t20: { type: Number, required: true },
  test: { type: Number, required: true },
  squads: { type: Number, required: true },
  matches: { type: Number, required: true }
});

// Create the model from the schema
const Series = mongoose.model('Series', seriesSchema);

module.exports = Series;