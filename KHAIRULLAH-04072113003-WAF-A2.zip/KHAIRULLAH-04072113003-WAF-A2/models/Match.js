const mongoose = require('mongoose');

const matchSchema = new mongoose.Schema({
  match_id: { type: String, required: true, unique: true },
  name: String,
  matchType: String,
  status: String,
  venue: String,
  date: Date,
  teams: [String],
  score: [
    {
      r: Number,
      w: Number,
      o: Number,
      inning: String
    }
  ]
});

const Match = mongoose.model('Match', matchSchema);

module.exports = Match;
