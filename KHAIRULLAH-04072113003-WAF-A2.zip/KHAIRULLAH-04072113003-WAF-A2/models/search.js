const mongoose = require('mongoose');

// Define schema for player data (if you plan to save the player data to DB)
const playerSchema = new mongoose.Schema({
  id: { type: String, required: true },
  name: { type: String, required: true },
  country: { type: String, required: true },
});

const Player = mongoose.model('Player', playerSchema);

module.exports = Player;
