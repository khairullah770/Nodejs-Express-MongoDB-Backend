// Importing required modules from 'fs/promises' for file system operations 
// and 'path' for handling and transforming file paths.
import fs from "fs/promises";
import path from "path";

// Define folder and file names.
const folderName = "part_1";
const folderpath = path.join(process.cwd(), folderName);

try {
    // Create a folder named "part_1" in the current working directory.
    await fs.mkdir(folderName, { recursive: true });
    console.log("Folder is created");
} catch (err) {
    // Handle error if the folder cannot be created.
    console.log("Error creating folder");
}

// Define file name and path for operations.
const fileName = "testfile.txt";
const filepath = path.join(process.cwd(), fileName);

try {
    // Create and write initial registration number into the file.
    await fs.writeFile(filepath, "04072113003");
    console.log("File is created and written");
} catch (err) {
    // Handle error if the file cannot be created or written to.
    console.log("Error creating and writing file");
}

try {
    // Read the data from the file and display it on the console.
    const data = await fs.readFile(filepath, "utf-8");
    console.log("File is read");
    console.log("My registration is:", data.toString());
} catch (err) {
    // Handle error if the file cannot be read.
    console.log("Error reading file");
}

try {
    // Overwrite the file with the last four digits of the registration number.
    const data = await fs.readFile(filepath, "utf-8");
    const lastFourDigits = data.slice(-4); // Extract last four digits.
    await fs.writeFile(filepath, lastFourDigits); // Overwrite file content.
    console.log("Overwrite registration:", lastFourDigits.toString());
} catch (err) {
    // Handle error if the file cannot be overwritten.
    console.log("Error overwriting last four digits of registration");
}

try {
    // Repeat the file read operation and display its current content.
    const data = await fs.readFile(filepath, "utf-8");
    console.log("File is read");
    console.log("My registration is:", data.toString());
} catch (err) {
    // Handle error if the file cannot be read.
    console.log("Error reading file");
}

try {
    // Erase the file content by writing an empty string.
    await fs.writeFile(filepath, "");
    console.log("Data is erased");
} catch (err) {
    // Handle error if the file content cannot be erased.
    console.log("Error erasing data");
}

try {
    // Repeat the operation to write the original registration number.
    await fs.writeFile(filepath, "04072113003");
    console.log("Registration is written again");
} catch (err) {
    // Handle error if the file cannot be rewritten.
    console.log("Error rewriting registration");
}
