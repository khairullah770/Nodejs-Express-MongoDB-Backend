function signup() {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            console.log("create account");
            resolve(); // Resolve the promise after delay
            //reject("error") //throw if any error
        }, 2000); // 2 seconds delay
    });
}

function sendVerificationCode() {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            console.log("Verification code sent.");
            resolve(); // Resolve the promise after delay
           //reject("error") //throw if any error
        }, 4000); // 4 seconds delay
    });
}

function signin() {
    return new Promise((resolve,reject) => {
        setTimeout(() => {
            console.log("Signin successfully");
            resolve(); // Resolve the promise after delay
            //reject("error") //throw if any error
        }, 3500); // 3.5 seconds delay
    });
}

function getData() {
    return new Promise((resolve,reject) => {
        setTimeout(() => {
            console.log("Data retrieved.");
            resolve(); // Resolve the promise after delay
            //reject("error") //throw if any error
        }, 4500); // 4.5 seconds delay
    });
}

function checkEmail() {
    return new Promise((resolve,reject) => {
        setTimeout(() => {
            console.log("Please check your email");
            resolve(); // Resolve the promise after delay
            //reject("error") //throw if any error
        }, 1500); // 1.5 seconds delay
    });
}

function composeEmail() {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            console.log("Email composed.");
            resolve(); // Resolve the promise after delay
            //reject("error") //throw if any error
        }, 2000); // 2 seconds delay
    });
}

function sendEmail() {
    return new Promise((resolve,reject) => {
        setTimeout(() => {
            console.log("Email sent successfully.");
            resolve(); // Resolve the promise after delay
            //reject("error") //throw if any error
        }, 3000); // 3 seconds delay
    });
}

async function executeWithAsyncAwait() {
    try {
        await signup();                
        await sendVerificationCode();  
        await signin();                
        await getData();               
        await checkEmail();            
        await composeEmail();          
        await sendEmail();             
        console.log("All tasks completed....."); // Final log after all tasks
    } catch (error) {
        console.error("Error:", error); // Catch any errors that occur
    }
}

// Start executing the functions in order using async/await
executeWithAsyncAwait();
