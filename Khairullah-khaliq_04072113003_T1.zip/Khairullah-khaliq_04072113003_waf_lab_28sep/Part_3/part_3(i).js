function signup() {
    setTimeout(() => {
        console.log("create account");
    }, 2000); // 2 seconds delay
}

function sendVerificationCode() {
    setTimeout(() => {
        console.log("Verification code sent.");
    }, 4000); // 4 seconds delay
}

function signin() {
    setTimeout(() => {
        console.log("Signin sucessfully");
    }, 3500); // 3.5 seconds delay
}

function getData() {
    setTimeout(() => {
        console.log("Data retrieved.");
    }, 4500); // 4.5 seconds delay
}

function checkEmail() {
    setTimeout(() => {
        console.log("Please check your email");
    }, 1500); // 1.5 seconds delay
}

function composeEmail() {
    setTimeout(() => {
        console.log("Email composed.");
    }, 2000); // 2 seconds delay
}

function sendEmail() {
    setTimeout(() => {
        console.log("Email sent sucessfully.");
    }, 3000); // 3 seconds delay
}


    signup();                  
    sendVerificationCode();    
    signin();                  
    getData();                 
    checkEmail();              
    composeEmail();          
    sendEmail();               

    console.log("All tasks completed.....");   // Final log after all tasks                               