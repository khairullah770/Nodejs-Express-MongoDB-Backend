function signup(callback) {
    setTimeout(() => {
        console.log("create account");
        callback();
    }, 2000); // 2 seconds delay
}

function sendVerificationCode(callback) {
    setTimeout(() => {
        console.log("Verification code sent.");
        callback();
    }, 4000); // 4 seconds delay
}

function signin(callback) {
    setTimeout(() => {
        console.log("Signin sucessfully");
        callback();
    }, 3500); // 3.5 seconds delay
}

function getData(callback) {
    setTimeout(() => {
        console.log("Data retrieved.");
        callback();
    }, 4500); // 4.5 seconds delay
}

function checkEmail(callback) {
    setTimeout(() => {
        console.log("Please check your email");
        callback();
    }, 1500); // 1.5 seconds delay
}

function composeEmail(callback) {
    setTimeout(() => {
        console.log("Email composed.");
        callback();
    }, 2000); // 2 seconds delay
}

function sendEmail(callback) {
    setTimeout(() => {
        console.log("Email sent sucessfully.");
        callback();
    }, 3000); // 3 seconds delay
}
signup(() => {
    sendVerificationCode(() => {
        signin(() => {
            getData(() => {
                checkEmail(() => {
                    composeEmail(() => {
                        sendEmail(() => {
                            console.log("All tasks completed.....");// Final log after all tasks
                        });
                    });
                });
            });
        });
    });
});                                   