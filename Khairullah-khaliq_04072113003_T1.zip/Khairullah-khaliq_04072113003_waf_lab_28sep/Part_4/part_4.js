// Importing required modules
const http = require("http"); // To create an HTTP server
const url = require("url"); // To parse URLs and query parameters
const fs = require("fs"); // To perform file operations

// Global variables
let serialNumber = 1; // To keep track of log entries
const PORT = 3000; // Port number for the server
const fileName = "./Part_4/log.txt"; // File to store log entries

// Function to log request details into the log.txt file
const log = (reqUrl, queryParams) => {
  const date = new Date(); // Current date and time
  const content = `${serialNumber++}. Date: ${date.toISOString()} | URL: ${reqUrl} | Query Params: ${
    Object.keys(queryParams).length
  }\n`; // Log entry format

  // Append the log entry to the log.txt file
  fs.appendFile(fileName, content, (err) => {
    if (err) {
      console.log(err); // Log error to console if write fails
    }
  });
};

// Function to append data into a specified file
const StoreData = (fileName, content) => {
  fs.appendFile(fileName, content, (err) => {
    if (err) {
      console.log(err); // Log error to console if write fails
    }
  });
};

// Create an HTTP server
http
  .createServer((req, res) => {
    let reUrl = req.url; // Full URL of the request
    const parsedUrl = url.parse(req.url, true); // Parse the URL
    const pathname = parsedUrl.pathname; // Extract the path
    const queryParams = parsedUrl.query; // Extract query parameters

    res.writeHead(200, { "Content-Type": "text/plain" }); // Set response headers

    // Routing logic based on the pathname
    switch (pathname) {
      case "/":
        log(reUrl, queryParams); // Log request details
        res.end("Home Page"); // Respond with Home Page message
        break;

      case "/users":
        log(reUrl, queryParams); // Log request details
        // Check if all required query parameters are present
        if (
          queryParams.id &&
          queryParams.name &&
          queryParams.age &&
          queryParams.city &&
          queryParams.uni
        ) {
          // Create a formatted string with user details
          const user = `ID: ${queryParams.id}, Name: ${queryParams.name}, Age: ${queryParams.age}, City: ${queryParams.city}, University: ${queryParams.uni} \n`;
          StoreData("./Part_4/users.txt", user); // Save user details to users.txt
          res.statusCode = 200;
          res.end(
            ` ID: ${queryParams.id}\n Name: ${queryParams.name}\n Age: ${queryParams.age}\n City: ${queryParams.city}\n University: ${queryParams.uni} \n`
          ); // Respond with user details
        } else {
          res.statusCode = 400; // Bad request if parameters are missing
          res.end("Something went Wrong with Product information");
        }
        break;

      case "/products":
        log(reUrl, queryParams); // Log request details
        // Check if all required query parameters are present
        if (queryParams.id && queryParams.title && queryParams.price) {
          // Create a formatted string with product details
          const productData = `ID: ${queryParams.id}, Title: ${queryParams.title}, Price: ${queryParams.price} \n`;
          StoreData("./Part_4/products.txt", productData); // Save product details to products.txt
          res.statusCode = 200;
          res.end(
            ` ID: ${queryParams.id}\n Title: ${queryParams.title}\n Price: ${queryParams.price} \n`
          ); // Respond with product details
        } else {
          res.statusCode = 400; // Bad request if parameters are missing
          res.end("Something went Wrong with Product information");
        }
        break;

      case "/display":
        log(reUrl, queryParams); // Log request details
        // Additional logic for displaying can be added here
        break;

      case "/books":
        log(reUrl, queryParams); // Log request details
        // Check if all required query parameters are present
        if (
          queryParams.id &&
          queryParams.title &&
          queryParams.edition &&
          queryParams.press
        ) {
          // Create a formatted string with book details
          const book = `ID: ${queryParams.id}, Title: ${queryParams.title}, Edition: ${queryParams.edition}, PressName: ${queryParams.press} \n`;
          StoreData("./Part_4/books.txt", book); // Save book details to books.txt
          res.statusCode = 200;
          res.end(
            `ID: ${queryParams.id}, Title: ${queryParams.title}, Edition: ${queryParams.edition}, PressName: ${queryParams.press} \n`
          ); // Respond with book details
        } else {
          res.statusCode = 400; // Bad request if parameters are missing
          res.end("Something went Wrong with Product information");
        }
        break;

      default:
        res.statusCode = 404; // Respond with 404 for unknown routes
        res.end("404 Not Found");
        break;
    }
  })
  .listen(PORT, () => {
    // Start the server and log a success message
    console.log(`Server Started on Port : ${PORT}`);
  });
