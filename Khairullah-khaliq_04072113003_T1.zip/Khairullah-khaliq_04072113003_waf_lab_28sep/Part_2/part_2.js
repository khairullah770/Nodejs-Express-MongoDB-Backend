// import fs from "fs/promises"
// import path from "path"

// const fileName = "ips.txt"
// const filepath = path.join(process.cwd(), fileName)
// try{
//     const data = await fs.readFile(fileName, 'utf8');
//     const ips = data.split('\n');

        
//         let A_ips = [];
//         let B_ips = [];
//         let C_ips = [];

        
//         ips.forEach(loopi => {
//             const ip_address = parseInt(loopi.split('.')[0]);  // in this method this gets only first octet

//             if (ip_address >= 1 && ip_address <= 126) {
//                 A_ips.push(loopi);
//             } else if (ip_address >= 127 && ip_address <= 191) {
//                 B_ips.push(loopi);
//             } else if (ip_address >= 192 && ip_address <= 223) {
//                 C_ips.push(loopi);
//             }
//         });

//         // Write categorized IPs to respective files using async/await
//         await fs.writeFile('A.txt', A_ips.join('\n'));
//         console.log('A.txt written successfully');

//         await fs.writeFile('B.txt', B_ips.join('\n'));
//         console.log('B.txt written successfully');

//         await fs.writeFile('C.txt', C_ips.join('\n'));
//         console.log('C.txt written successfully');

//     } catch (err) {
//         console.error('Error tooo many....');

// }

import fs from "fs/promises";
import path from "path";

const fileName = "./Part_2/ips.txt";
const filepath = path.join(process.cwd(), fileName);

(async () => {
    try {
        // Read the IP addresses from Ips.txt
        const data = await fs.readFile(filepath, 'utf8');

        // Split the data into lines (IP addresses)
        const ips = data.split('\n').filter(ip => ip.trim() !== ""); // Remove empty lines

        // Open file handles for writing categorized IPs
        const aFile = await fs.open('A.txt', 'w');
        const bFile = await fs.open('B.txt', 'w');
        const cFile = await fs.open('C.txt', 'w');

        // Loop through the IPs and categorize based on the first octet
        for (let ip of ips) {
            const firstOctet = parseInt(ip.split('.')[0]);

            if (firstOctet >= 1 && firstOctet <= 126) {
                await aFile.write(ip + '\n'); // Write Class A IP to A.txt
            } else if (firstOctet >= 128 && firstOctet <= 191) {
                await bFile.write(ip + '\n'); // Write Class B IP to B.txt
            } else if (firstOctet >= 192 && firstOctet <= 223) {
                await cFile.write(ip + '\n'); // Write Class C IP to C.txt
            }
        }

        // Close the file handles
        await aFile.close();
        await bFile.close();
        await cFile.close();

        console.log('A.txt written successfully');
        console.log('B.txt written successfully');
        console.log('C.txt written successfully');
    } catch (err) {
        console.error('Error processing IP addresses:', err);
    }
})();


