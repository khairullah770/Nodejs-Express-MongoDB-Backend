import express from 'express';
import fs from 'fs';

const app = express();
const PORT = 8080;
const chatHistoryFile = 'chat.txt';

app.get('/msg', (req, res) => {
    const message = req.query.message;

    if (!message) {
        return res.status(400).send('No message provided');
    }

    const timestamp = new Date().toISOString();
    const logEntry = `${timestamp} - Received: ${message}\n`;

    fs.appendFile(chatHistoryFile, logEntry, (err) => {
        if (err) {
            console.error("Failed to write to chat history:", err);
            return res.status(500).send('Error logging chat history');
        }
        res.send('your message is received and logged');
    });
});

// Start the Express server
app.listen(PORT, () => {
    console.log(`Chat server is running, now you send message !!. Send messages: to http://<YOUR_PC_IP>:${PORT}/msg?message=your_message`);
});
