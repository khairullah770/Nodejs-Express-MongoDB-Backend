// npm install -g chalk
// npm install -g colors
// npm install -g validator
// npm install -g prompt
// npm list -g –depth=0 command to display the list of installed
// packages.