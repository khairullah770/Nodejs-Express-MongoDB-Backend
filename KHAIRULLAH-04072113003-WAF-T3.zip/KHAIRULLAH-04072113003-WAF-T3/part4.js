const fs = require('fs');
const readline = require('readline');
const ipValidator = require('ip');
const colors = require('colors');


// This is for input
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

// Function to validate if the email format is correct
function isValidEmail(email) {
  const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
  return emailRegex.test(email);
}

// Function to validate if the IP address is in correct IPv4 format
function isValidIP(ip) {
  return ipValidator.isV4Format(ip);
}

// Function to check the IP address in both JSON files
function checkIP(ip) {
  // Read White.json
  fs.readFile('White.json', 'utf8', (err, whiteData) => {
    if (err) {
      console.log(colors.red(`Error reading White.json: ${err}`));
      return;
    }

    const whiteList = JSON.parse(whiteData);

    // Check if the IP exists in White.json
    const whiteMatch = whiteList.find(item => item.ip_address === ip);
    if (whiteMatch) {
      console.log(colors.green('Authentication success message.'));
      return;
    }

    // If not found in White.json, check Black.json
    fs.readFile('Black.json', 'utf8', (err, blackData) => {
      if (err) {
        console.log(colors.red(`Error reading Black.json: ${err}`));
        return;
      }

      const blackList = JSON.parse(blackData);
      const blackMatch = blackList.find(item => item.ip_address === ip);

      if (blackMatch) {
        console.log(colors.red('Error: IP is blocked.'));
      } else {
        console.log(colors.yellow('IP Address not found in either file'));
        
        // If the IP is not in either White.json or Black.json, write it to pending.json
        fs.readFile('pending.json', 'utf8', (err, pendingData) => {
          let pendingList = [];
          
          if (!err) {
            pendingList = JSON.parse(pendingData);
          }

          // Add the IP to the pending list
          pendingList.push({ ip_address: ip });

          // Write the updated pending list to pending.json
          fs.writeFile('pending.json', JSON.stringify(pendingList, null, 2), (err) => {
            if (err) {
              console.log(colors.red(`Error writing to pending.json: ${err}`));
            } else {
              console.log(colors.yellow('The user an error message communicating that the system is unable to authenticate the IP.'));
            }
          });
        });
      }
    });
  });
}

// Prompt for the email address and IP address
rl.question('Please enter an email address: ', (email) => {
  if (!isValidEmail(email)) {
    console.log(colors.red('Invalid email address format'));
  } else {
    console.log(colors.green('Email address is valid'));
  }

  rl.question('Please enter an IPv4 address: ', (ip) => {
    if (!isValidIP(ip)) {
      console.log(colors.red('Invalid IP address format'));
    } else {
      console.log(colors.green('IP address is valid'));
      checkIP(ip);
    }
    rl.close();
  });
});
