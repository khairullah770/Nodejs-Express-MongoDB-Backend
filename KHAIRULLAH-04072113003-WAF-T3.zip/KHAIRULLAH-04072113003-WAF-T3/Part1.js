// os and path import
const os = require('os');
const path = require('path');

//  Print system uptime using the os module
const uptimeInSeconds = os.uptime();
const uptimeInHours = Math.floor(uptimeInSeconds / 3600);  // Convert seconds to hours
const remainingMinutes = Math.floor((uptimeInSeconds % 3600) / 60); // Remaining minutes

console.log(`System Uptime : ${uptimeInHours} and hours, ${remainingMinutes} minutes`);

// Use path module to parse the current .js file 
const currentFilePath = __filename; // This will give the full path of the current file
const parsedPath = path.parse(currentFilePath);  // Parse the path for details

//consoling my my file information
console.log('This is my File Information:');
console.log(`Root: ${parsedPath.root}`);
console.log(`Directory: ${parsedPath.dir}`);
console.log(`Base Filename: ${parsedPath.base}`);
console.log(`Extension: ${parsedPath.ext}`);
console.log(`Name (without extension): ${parsedPath.name}`);
