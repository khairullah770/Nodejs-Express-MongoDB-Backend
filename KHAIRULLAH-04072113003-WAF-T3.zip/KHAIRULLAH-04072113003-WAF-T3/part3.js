// Use the 'import' 
import chalk from 'chalk';
import readline from 'readline';


const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

// Prompt the user for their name
rl.question('Please enter your name: ', (name) => {
    // Validate if the first letter is uppercase
    if (name.charAt(0) === name.charAt(0).toUpperCase()) {
        // Display name with custom color (text color green, background color yellow)
        console.log(chalk.bgYellow.green(`Your Name: ${name}`));
    } else {
        // Display error message with custom color (text color white, background color red)
        console.log(chalk.bgRed.white(`Error: The first letter should be capitalized!: ${name}`));
    }

    
    rl.close();
});
