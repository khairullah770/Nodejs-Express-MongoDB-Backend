const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');

// Signup routes
router.get('/signup', userController.renderSignupPage);
router.post('/signup', userController.handleSignup);

// Login routes
router.get('/login', userController.renderLoginPage);
router.post('/login', userController.handleLogin);

module.exports = router;
