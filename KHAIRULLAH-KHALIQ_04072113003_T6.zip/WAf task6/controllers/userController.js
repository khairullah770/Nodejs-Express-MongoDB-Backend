const User = require('../models/userModel'); // Ensure correct path
const City = require('../models/cityModel'); // Ensure correct path
const bcrypt = require('bcrypt');
const { validationResult } = require('express-validator');

// Render the signup page
exports.renderSignupPage = (req, res) => {
    // Fetch cities for dropdown
    City.find({}, (err, cities) => {
        if (err) {
            console.error('Error fetching cities:', err);
            return res.render('signup', { errors: ['Failed to load cities'], cities: [] });
        }
        res.render('signup', { cities });
    });
};

// Handle the signup process
exports.handleSignup = (req, res) => {
    const { email, password, name, gender, city, dob, occupation } = req.body;
    const errors = validationResult(req); // Capture validation errors

    if (!errors.isEmpty()) {
        // If there are validation errors, return with them
        return res.render('signup', { errors: errors.array() });
    }

    // Check if the email already exists
    User.findOne({ email }, (err, existingUser) => {
        if (err) {
            console.error('Error checking for existing user:', err);
            return res.render('signup', { errors: ['Error checking user existence'], cities: [] });
        }
        
        if (existingUser) {
            return res.render('signup', { errors: ['Email already in use'], cities: [] });
        }

        // Hash the password before saving it
        bcrypt.hash(password, 10, (err, hashedPassword) => {
            if (err) {
                console.error('Error hashing password:', err);
                return res.render('signup', { errors: ['Error hashing password'], cities: [] });
            }

            // Create the new user
            const newUser = new User({
                email,
                password: hashedPassword,
                name,
                gender,
                city,
                dob,
                occupation,
            });

            // Save the new user to the database
            newUser.save((err) => {
                if (err) {
                    console.error('Error saving user:', err);
                    return res.render('signup', { errors: ['Error saving user'], cities: [] });
                }

                // Redirect to login page after successful signup
                res.redirect('/login');
            });
        });
    });
};
